#!/usr/bin/env python
# coding: utf-8

# # Project: Investigate a Dataset - [TMDB 5000 Movie]
# 
# ## Table of Contents
# <ul>
# <li><a href="#intro">Introduction</a></li>
# <li><a href="#wrangling">Data Wrangling</a></li>
# <li><a href="#eda">Exploratory Data Analysis</a></li>
# <li><a href="#conclusions">Conclusions</a></li>

# <a id='intro'></a>
# ## Introduction
# 
# ### Dataset Description 
# 
# The dataset under analysis consists of 10,000 movies sourced from The Movie Database (TMDb). This dataset offers valuable insights into the dynamics of the film industry, including factors influencing movie success and the impact of inflation on financial outcomes. It provides insights into various aspects such as genre popularity, financial success of movies, and the performance of directors and actors. The dataset is particularly useful for understanding the relationship between budget, revenue, and profit, as well as the factors contributing to a movie's success.
# <li>Budget: The financial investment for the production of a movie. It's a significant column for understanding the financial aspect of a movie's production</li>
# <li>Genres: The genre(s) of the movie. It's an important factor for understanding the type of movie and its potential audience</li>
# <li>Homepage: The homepage URL of the movie. It can be used for further research or promotional purposes</li>
# <li>Id: The unique identifier for each movie. It's crucial for referencing and linking to other datasets</li>
# <li>Keywords: Keywords associated with the movie. They can be used for categorization and search purposes</li>
# <li>Original_language: The original language of the movie. It helps in understanding the cultural context and potential audience</li>
# <li>Original_title: The original title of the movie. It's significant for understanding the movie's name in its original language</li>
# <li>Overview: A brief description or summary of the movie's plot. It's crucial for understanding the movie's content</li>
# <li>Popularity: The popularity rating of the movie. It's an important factor for understanding the movie's appeal to the general audience</li>
# <li>Production_companies: The production companies involved in the movie. It's significant for understanding the financial and production aspects of the movie</li>
# <li>Production_countries: The countries where the movie was produced. It's an important factor for understanding the cultural context</li>
# <li>Release_date: The date when the movie was released</li>
# 
#     
# ### Question(s) for Analysis
# 
# 1. What is the relationship between the average budget and revenue for the top-performing movie genres?
# 
# 2. How have film budgets changed on average every five years?
# 
# 3. What are the top-performing directors in terms of total revenue, among those who have directed at least 10 movies?

# In[32]:


# Import statements for all of the packages that I plan to use.

# Data manipulation
import pandas as pd
import numpy as np

# Data visualization
import matplotlib.pyplot as plt
import seaborn as sns

# Statistical analysis
from scipy import stats

# magic word
get_ipython().run_line_magic('matplotlib', 'inline')


# <a id='wrangling'></a>
# ## Data Wrangling

# In[33]:


# Load and examine
df = pd.read_csv('Database_TMDb_movie_data/tmdb-movies.csv')
df.head()


# In[34]:


# The total number of elements in the DataFrame
print(df.size)

# The dimensions of the DataFrame (rows, columns)
print(df.shape)


# ### Conducting 4-6 operations using dataframe methods to examine data types and identify potential instances of missing or erroneous data.

# In[35]:


# 1st - Checking for null values

print(df.info())


# In[36]:


# 2nd - identifies duplicate rows

duplicate_rows = df[df.duplicated()]

if not duplicate_rows.empty:
    print("Duplicate rows found:")
    print(duplicate_rows)
else:
    print("No duplicate rows found.")


# In[37]:


# 3rd - Counts missing values

print(df.isnull().sum())


# In[38]:


# 4th - Provides summary statistics

print(df.describe())


# In[39]:


# 5th - Displays data types

print(df.dtypes)


# In[40]:


# 6th - Determines the dataset's range of years.

df.release_year.max(), df.release_year.min()


# In[41]:


#   7th - Shows the number of unique values in each column.

print(df.nunique())


# ##  Data Problems
# 
#  1) Some column types are incorrect and needs to be changed
#  
#  2) There is one duplicate row
#  
#  
#  3) Popularity points lacks clarity. It's unclear how this metric was assessed or calculated.
#  
#  
#  4) Rectify the missing values in the columns listed below, as they should not contain any missing data.
#     - imdb_id                   10
#     - cast                      76
#     - homepage                7930
#     - director                  44
#     - tagline                 2824
#     - keywords                1493
#     - overview                   4
#     - genres                    23
#     - production_companies    1030
#     
#   5) Columns 'budget' and 'revenue' contain numerous '0' values, which is abnormal and lacks clarity.
#   
#   6) Column 'genre' contains multiple values seperated by '|'
#     
# ## Data Cleaning 
# 
#  1) Remove columns not being used
#  
#  2) Change the following column types
#     - release_date: Convert to datetime
#     - genres: Convert to category
#     
#  3) Delete duplicate row with ID: 42194
#  
#  4) Delete rows with blank values in columns genre, and directors 
#  
#  5) Delete rows with '0' values in the 'budget' and 'revenue' columns due to uncertainty. 
#  
#  6) Extract unique values from the 'genre' column separated by '|' to ensure accurate calculation by creating separate rows for each.
#  
#  
#  
#  

# ## Performing Data Cleansing 

# In[42]:


# Copy of original df
TMDB=df.copy()


# In[43]:


# Remove columns I do not plan on using
col = ['imdb_id', 'popularity', 'homepage', 'tagline', 'keywords', 'overview', 'runtime','vote_count', 'vote_average']
TMDB.drop(col, axis=1, inplace=True)


# In[44]:


# Confirm column headers
TMDB.head(1)


# In[45]:


# Change column types for release_date and genre
TMDB['release_date'] = pd.to_datetime(TMDB['release_date'])

# Convert 'genres' column to category
TMDB['genres'] = TMDB['genres'].astype('category')


# In[46]:


#drop duplicated rows
TMDB.drop_duplicates(inplace=True)


# In[47]:


# delete nulls in director and genres column
drop_columns = ['genres', 'director']

# Drop rows with null values in specified columns
TMDB.dropna(subset=drop_columns, how='any', inplace=True)


# In[48]:


# Delete rows with '0' values in the 'budget' and 'revenue' columns
TMDB = TMDB[(TMDB['budget'] != 0) & (TMDB['revenue'] != 0)]


# In[49]:


# Performing genre separation and generating additional rows for each genre
genre_split = TMDB['genres'].str.split('|', expand=True).stack().reset_index(level=1, drop=True)

# Assigning a name to the newly created column
genre_split.name = 'genre'

# Integrating the newly created column with the original DataFrame
TMDB = TMDB.drop('genres', axis=1).join(genre_split)

# Displaying the top 10 rows with columns 'id', 'original_title', and 'genre'
print(TMDB[['id', 'original_title', 'genre']].head(10))


# <a id='eda'></a>
# ## Exploratory Data Analysis

# ### Research Question 1 What is the relationship between the average budget and revenue for the top-performing movie genres?

# In[50]:


# Step 1: Filter out movies with missing values in 'genre' or 'revenue' columns
TMDB.dropna(subset=['genre', 'revenue'], inplace=True)

# Check if there are any missing values in 'genre' or 'revenue' columns
missing_values = TMDB[['genre', 'revenue']].isnull().any()

# If there are no missing values, the filter worked
if not missing_values.any():
    print("Filtering successful: No missing values in 'genre' or 'revenue' columns.")
else:
    print("Filtering failed: There are still missing values in 'genre' or 'revenue' columns.")


# In[51]:


# Step 2: Group by 'genre' and calculate average budget and revenue
genre_stats = TMDB.groupby('genre').agg({'budget': 'mean', 'revenue': 'mean'})


# In[52]:


# Step 3: Sort genres by total revenue in descending order
sorted_genres = genre_stats.sort_values(by='revenue', ascending=False)


# In[53]:


# Step 7: Select the top 15 genres
top_15_genres = sorted_genres.head(15)
print("Top 15 genres selected.")


# In[54]:


# Step 8: Print the top 15 genres with their average budget and total revenue
print("Top 15 Highest Revenue Movie Genres and Average Budget:")
print(top_15_genres)


# In[55]:


# Step 8: Visualize the top 15 genres and their average budget
plt.figure(figsize=(12, 6))
# Plot average budget on the left y-axis
ax1 = plt.gca()
top_15_genres['budget'].plot(kind='line', ax=ax1, color='red', linestyle='-', marker='o', label='Average Budget')
ax1.set_ylabel('Average Budget')

# Create a secondary y-axis for revenue
ax2 = ax1.twinx()
top_15_genres['revenue'].plot(kind='bar', ax=ax2, color='skyblue', alpha=0.7, label='Average Revenue')
ax2.set_ylabel('Average Revenue')

# Set title and labels
plt.title('Average Budget and Revenue for Top 15 Highest Revenue Movie Genres')
ax1.set_xlabel('Genres')
ax1.set_xticklabels(top_15_genres.index, rotation=45, ha='right')

# Add legend
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
lines = lines1 + lines2
labels = labels1 + labels2
plt.legend(lines, labels, loc='upper left')

# Show plot
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()


# ### Research Question 2  How have film budgets changed on average every five years?

# In[56]:


# Step 1: Define Function to Calculate Average Budget Change
def average_budget_change(data, start_year, end_year):
    subset = data[(data['release_year'] >= start_year) & (data['release_year'] < end_year)]
    average_budget = subset['budget'].mean()
    return average_budget


# In[57]:


# Step 2: Analyze Data Over Five-Year Periods
start_years = range(1960, 2020, 5)
end_years = range(1965, 2025, 5)

average_budgets = []
for start, end in zip(start_years, end_years):
    avg_budget = average_budget_change(TMDB, start, end)  # Remove str() conversion
    average_budgets.append(avg_budget)

# Print the results
print("Average budget for each five-year period:")
for i, start_year in enumerate(start_years):
    print(f"  - {start_year}-{start_year+4}: ${average_budgets[i]:,.2f}")


# In[58]:


# Step 3: Plotting
plt.figure(figsize=(10, 6))
plt.plot(start_years, average_budgets, marker='o')
plt.title('Average Film Budget Change Over Five-Year Periods')
plt.xlabel('Year')
plt.ylabel('Average Budget ($)')
plt.grid(True)
plt.xticks(start_years)
plt.tight_layout()
plt.show()


# ### Research Question 3  What are the top-performing directors in terms of total revenue, among those who have directed at least 10 movies?

# In[59]:


# Step 1: Group by director and calculate total revenue
director_revenue = TMDB.groupby('director')['revenue'].sum().reset_index()


# In[60]:


# Step 2: Find the top 10 directors with the highest total revenue
top_directors = director_revenue.nlargest(10, 'revenue')
print(top_directors)


# In[61]:


# Step 3: Visualize the results using a bar plot
plt.figure(figsize=(12, 6))
sns.barplot(data=top_directors, x='director', y='revenue', palette='viridis')
plt.title('Top 10 Directors with the Highest Total Revenue')
plt.xlabel('Director')
plt.ylabel('Total Revenue')
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()


# # <a id='conclusions'></a>
# ## Conclusions
# 
# 
# Conclusions:
# 
# **1. Relationship Between Average Budget and Revenue for Top-Performing Movie Genres**
# 
# The analysis dived into examining the relationship between the average budget and revenue for top-performing movie genres. It was noted that genres such as Animation, Adventure, Fantasy, and Family appeared to yield the highest average revenues. This suggests these genres have a solid commercial appeal and tend to perform well at the box office. However, despite their high revenues, these genres also exhibited relatively high average budgets, indicating significant investments in production. This likely stems from the need for advanced special effects, animation, and production design. Additionally, genres like Action, Science Fiction, and Thriller, while not boasting the highest budgets compared to genres like Animation, still managed to generate substantial returns, reflecting audience preferences. While investing in genres such as Animation, Adventure, and Fantasy seems promising for high returns on investment, maintaining a balance in budget allocation is crucial to ensuring profitability. Overall, this analysis offers insights that can assist filmmakers, producers, and investors in navigating market trends and making informed decisions in the film industry.
# 
# **Limitation:** 
# It's important to note a limitation in the analysis due to the absence of certain data that could provide a more comprehensive understanding. Factors like marketing budgets, distribution strategies, and audience demographics, although influential, were not included in the dataset, potentially limiting the depth of insights derived.
# 
# **2. Changes in Film Budgets Over Five-Year Periods**
# 
# The analysis investigated the average changes in film budgets over five-year periods. It was observed that there is a general increasing trend in average film budgets over the years, suggesting a tendency towards higher production costs in the film industry. Notable periods of rapid growth in average film budgets were identified, such as the transition from the 1990s to the 2000s, where there was a significant surge from around $26 million to nearly $50 million. Despite this overall upward trend, there were also periods of relatively stable average budgets, particularly from the late 1970s to the early 1990s. However, recent trends indicate another significant increase in average film budgets, particularly from 2010 onwards, with figures surpassing $50 million.
# 
# **3. Top-Performing Directors in Terms of Total Revenue**
# 
# The analysis highlighted the top-performing directors in terms of total revenue among those who have directed at least 10 movies. Directors such as Steven Spielberg, James Cameron, and Peter Jackson emerged as significant influencers in the film industry, occupying the top positions in terms of total revenue. Their consistent track record of delivering financially successful films over the years underscores their impact. The success of these directors reflects the importance of investing in talented filmmakers with a proven track record of delivering successful projects. Studios and producers may continue to prioritize collaborations with established directors to mitigate risks and maximize returns on investment.
# 
# **Additional Research Opportunities:**
# Further research opportunities lie in exploring the specific factors contributing to the observed trends in film budgets and revenue. Factors such as changes in production technologies, shifts in audience preferences, or the influence of global markets on the film industry could be investigated. Additionally, delving into the role of marketing strategies and distribution channels in driving movie revenue could provide deeper insights into the dynamics of the industry.
